$(document).ready(function () {
  var buttonAdd = $("#add-button");
  var buttonRemove = $("#remove-button");
  var className = ".dynamic-field";
  let count = 1;
  var field = "";
  var maxFields = 5;
  let arr;
  let input__labels;

  function totalFields() {
    return $(className).length;
  }

  function addNewField() {
    count = totalFields() + 1;
    field = $("#dynamic-field-1").clone();
    field.attr("id", "dynamic-field-" + count);
    field.children("label").text("Field " + count);
    field.find("input").val("");
    $(className + ":last").after($(field));
  }

  function removeLastField() {
    if (totalFields() > 1) {
      $(className + ":last").remove();
    }
  }

  function enableButtonRemove() {
    if (totalFields() === 2) {
      buttonRemove.removeAttr("disabled");
      buttonRemove.addClass("shadow-sm");
    }
  }

  function disableButtonRemove() {
    if (totalFields() === 1) {
      buttonRemove.attr("disabled", "disabled");
      buttonRemove.removeClass("shadow-sm");
    }
  }

  function disableButtonAdd() {
    if (totalFields() === maxFields) {
      buttonAdd.attr("disabled", "disabled");
      buttonAdd.removeClass("shadow-sm");
    }
  }

  function enableButtonAdd() {
    if (totalFields() === (maxFields - 1)) {
      buttonAdd.removeAttr("disabled");
      buttonAdd.addClass("shadow-sm");
    }
  }

  buttonAdd.click(function () {
    addNewField();
    enableButtonRemove();
    disableButtonAdd();
  });

  buttonRemove.click(function () {
    removeLastField();
    disableButtonRemove();
    enableButtonAdd();
  });

  $('.Form-create-button').on('click', function (e) {

    input__labels = new Array(count)
    let i = 0

    $('#exampleModalCenter').modal('show');
    //e.preventDefault();
    
    $('.form-control').each( function() {
      input__labels[i] = ($(this).val())
      i++
    })
    
    let label__content = []
    for(i = 0 ; i < count ; i++){
      label__content[i] = `<div class="ModalFormInput"><label>${input__labels[i]}</label> <input type='text' placeholder='${input__labels[i]}' id=${"id"+i} /> </div>`
    }

    for(i = 0 ; i < count ; i++){
      const label__field = document.createElement('div')
      label__field.classList.add('input__field')
      label__field.innerHTML = label__content[i]
      $('.my__form').append(label__field)
    }

    //console.log(label__content)
  });

  $('.closingbutton').on('click',function(){
      location.reload();
  });

  $('.FormSubmit').on('click',function(){
     arr = new Array(count)
      for(i =0 ;i < count ;i++){
          arr[i]= document.getElementById("id"+i).value;
      }

      let table__arr =new Array(arr.length)
      let numbers = table__arr.length;

      for(i=0;i<arr.length;i++){
        table__arr[i] = `<div class="new__entry">${input__labels[i]}<label></label> <h3>${arr[i]}</h3></div>`
      }
    
      for(i=0;i<numbers;i++){
          const data__data = table__arr[i]
          $('.All_table__data').append(data__data)
      }
      
      
  });

 

});